## How to use

```sh
https://github.com/bracu-mongoltori/ros2-webgui
cd ros2-webgui
npm install
npm start
ros2 launch rosbridge_server rosbridge_websocket_launch.xml
cd mapproxy
mapproxy-util serve-develop ./mapproxy.yaml
```
